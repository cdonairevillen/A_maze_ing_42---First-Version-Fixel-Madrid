from setuptools import setup

setup(
    name="mazegen",
    version="1.0.1",
    description="Maze generator solver (A-maze-ing 42)",
    py_modules=["a_maze_ing"],
    packages=["mlx"],
    package_data={
        "mlx": ["*.so", "docs/*.h"],  # incluimos librerías y headers
    },
    include_package_data=True,
)